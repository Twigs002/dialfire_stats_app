import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertCallSchema, insertCallerSchema, insertTeamSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Dashboard stats
  app.get("/api/dashboard/stats/:campaignId", async (req, res) => {
    try {
      const { campaignId } = req.params;
      const { startDate, endDate } = req.query;
      
      const start = startDate ? new Date(startDate as string) : undefined;
      const end = endDate ? new Date(endDate as string) : undefined;
      
      const stats = await storage.getDashboardStats(campaignId, start, end);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch dashboard stats",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Caller statistics
  app.get("/api/callers/stats/:campaignId", async (req, res) => {
    try {
      const { campaignId } = req.params;
      const { startDate, endDate } = req.query;
      
      const start = startDate ? new Date(startDate as string) : undefined;
      const end = endDate ? new Date(endDate as string) : undefined;
      
      const stats = await storage.getCallerStats(campaignId, start, end);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch caller statistics",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Team statistics
  app.get("/api/teams/stats/:campaignId", async (req, res) => {
    try {
      const { campaignId } = req.params;
      const { startDate, endDate } = req.query;
      
      const start = startDate ? new Date(startDate as string) : undefined;
      const end = endDate ? new Date(endDate as string) : undefined;
      
      const stats = await storage.getTeamStats(campaignId, start, end);
      res.json(stats);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch team statistics",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get all teams
  app.get("/api/teams", async (req, res) => {
    try {
      const teams = await storage.getAllTeams();
      res.json(teams);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch teams",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Create team
  app.post("/api/teams", async (req, res) => {
    try {
      const teamData = insertTeamSchema.parse(req.body);
      const team = await storage.createTeam(teamData);
      res.status(201).json(team);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Invalid team data",
          errors: error.errors
        });
      } else {
        res.status(500).json({ 
          message: "Failed to create team",
          error: error instanceof Error ? error.message : "Unknown error"
        });
      }
    }
  });

  // Get threshold alerts
  app.get("/api/alerts/:campaignId", async (req, res) => {
    try {
      const { campaignId } = req.params;
      const alerts = await storage.getActiveAlerts(campaignId);
      res.json(alerts);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch alerts",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Get campaign thresholds
  app.get("/api/thresholds/:campaignId", async (req, res) => {
    try {
      const { campaignId } = req.params;
      const threshold = await storage.getThreshold(campaignId);
      
      if (!threshold) {
        res.status(404).json({ message: "Threshold configuration not found" });
        return;
      }
      
      res.json(threshold);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch thresholds",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Update campaign thresholds
  app.put("/api/thresholds/:campaignId", async (req, res) => {
    try {
      const { campaignId } = req.params;
      const updateData = req.body;
      
      const threshold = await storage.updateThreshold(campaignId, updateData);
      res.json(threshold);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to update thresholds",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // DialFire API proxy endpoints
  app.post("/api/dialfire/sync-calls", async (req, res) => {
    try {
      const { campaignId, startDate, endDate } = req.body;
      
      // This would integrate with DialFire API
      // For now, return a success message
      res.json({ 
        message: "Call sync initiated",
        status: "pending"
      });
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to sync calls from DialFire",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Create caller from DialFire data
  app.post("/api/callers", async (req, res) => {
    try {
      const callerData = insertCallerSchema.parse(req.body);
      const caller = await storage.createCaller(callerData);
      res.status(201).json(caller);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Invalid caller data",
          errors: error.errors
        });
      } else {
        res.status(500).json({ 
          message: "Failed to create caller",
          error: error instanceof Error ? error.message : "Unknown error"
        });
      }
    }
  });

  // Create call record
  app.post("/api/calls", async (req, res) => {
    try {
      const callData = insertCallSchema.parse(req.body);
      const call = await storage.createCall(callData);
      res.status(201).json(call);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ 
          message: "Invalid call data",
          errors: error.errors
        });
      } else {
        res.status(500).json({ 
          message: "Failed to create call record",
          error: error instanceof Error ? error.message : "Unknown error"
        });
      }
    }
  });

  // Get all campaigns
  app.get("/api/campaigns", async (req, res) => {
    try {
      const campaigns = await storage.getAllCampaigns();
      res.json(campaigns);
    } catch (error) {
      res.status(500).json({ 
        message: "Failed to fetch campaigns",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
