import { 
  type Campaign, type InsertCampaign,
  type Team, type InsertTeam,
  type Caller, type InsertCaller,
  type Call, type InsertCall,
  type Threshold, type InsertThreshold,
  type Alert, type InsertAlert,
  type CallerStats, type TeamStats, type DashboardStats
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Campaign methods
  getCampaign(id: string): Promise<Campaign | undefined>;
  getCampaignByDialfireId(dialfireId: string): Promise<Campaign | undefined>;
  createCampaign(campaign: InsertCampaign): Promise<Campaign>;
  getAllCampaigns(): Promise<Campaign[]>;

  // Team methods
  getTeam(id: string): Promise<Team | undefined>;
  getTeamByContactOwnerId(contactOwnerId: string): Promise<Team | undefined>;
  createTeam(team: InsertTeam): Promise<Team>;
  getTeamsByCampaign(campaignId: string): Promise<Team[]>;
  getAllTeams(): Promise<Team[]>;

  // Caller methods
  getCaller(id: string): Promise<Caller | undefined>;
  getCallerByDialfireId(dialfireId: string): Promise<Caller | undefined>;
  createCaller(caller: InsertCaller): Promise<Caller>;
  getCallersByTeam(teamId: string): Promise<Caller[]>;
  getAllCallers(): Promise<Caller[]>;

  // Call methods
  createCall(call: InsertCall): Promise<Call>;
  getCallsByCaller(callerId: string, startDate?: Date, endDate?: Date): Promise<Call[]>;
  getCallsByCampaign(campaignId: string, startDate?: Date, endDate?: Date): Promise<Call[]>;
  getCallsByTeam(teamId: string, startDate?: Date, endDate?: Date): Promise<Call[]>;

  // Threshold methods
  getThreshold(campaignId: string): Promise<Threshold | undefined>;
  createThreshold(threshold: InsertThreshold): Promise<Threshold>;
  updateThreshold(campaignId: string, threshold: Partial<InsertThreshold>): Promise<Threshold>;

  // Alert methods
  createAlert(alert: InsertAlert): Promise<Alert>;
  getActiveAlerts(campaignId?: string): Promise<Alert[]>;
  dismissAlert(alertId: string): Promise<void>;

  // Analytics methods
  getDashboardStats(campaignId: string, startDate?: Date, endDate?: Date): Promise<DashboardStats>;
  getCallerStats(campaignId: string, startDate?: Date, endDate?: Date): Promise<CallerStats[]>;
  getTeamStats(campaignId: string, startDate?: Date, endDate?: Date): Promise<TeamStats[]>;
}

export class MemStorage implements IStorage {
  private campaigns: Map<string, Campaign> = new Map();
  private teams: Map<string, Team> = new Map();
  private callers: Map<string, Caller> = new Map();
  private calls: Map<string, Call> = new Map();
  private thresholds: Map<string, Threshold> = new Map();
  private alerts: Map<string, Alert> = new Map();

  constructor() {
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Create default campaign
    const campaign: Campaign = {
      id: "default-campaign",
      name: "Main Campaign",
      dialfireId: "campaign_001",
      isActive: true,
      createdAt: new Date(),
    };
    this.campaigns.set(campaign.id, campaign);

    // Create default teams
    const teams: Team[] = [
      { id: "team-assassins", name: "Assassins", contactOwnerId: "1234", campaignId: campaign.id },
      { id: "team-warriors", name: "Warriors", contactOwnerId: "5678", campaignId: campaign.id },
      { id: "team-titans", name: "Titans", contactOwnerId: "9012", campaignId: campaign.id },
    ];
    teams.forEach(team => this.teams.set(team.id, team));

    // Create default threshold
    const threshold: Threshold = {
      id: "default-threshold",
      campaignId: campaign.id,
      minDailyCalls: 50,
      minSuccessRate: "70.00",
      minAvgDuration: 240,
      weeklyTarget: 350,
    };
    this.thresholds.set(campaign.id, threshold);

    // Create sample callers
    const callers: Caller[] = [
      { id: "caller-1", name: "John Smith", dialfireId: "df_001", teamId: "team-assassins", isActive: true },
      { id: "caller-2", name: "Sarah Johnson", dialfireId: "df_002", teamId: "team-assassins", isActive: true },
      { id: "caller-3", name: "Mike Davis", dialfireId: "df_003", teamId: "team-warriors", isActive: true },
      { id: "caller-4", name: "Emily Brown", dialfireId: "df_004", teamId: "team-warriors", isActive: true },
      { id: "caller-5", name: "David Wilson", dialfireId: "df_005", teamId: "team-titans", isActive: true },
      { id: "caller-6", name: "Lisa Anderson", dialfireId: "df_006", teamId: "team-titans", isActive: true },
    ];
    callers.forEach(caller => this.callers.set(caller.id, caller));

    // Create sample calls for the last 7 days
    const today = new Date();
    const sampleCalls: Call[] = [];
    
    callers.forEach((caller, callerIndex) => {
      for (let day = 0; day < 7; day++) {
        const callDate = new Date(today);
        callDate.setDate(callDate.getDate() - day);
        
        // Vary the number of calls per day per caller
        const callsPerDay = Math.floor(Math.random() * 30) + 30; // 30-60 calls per day
        
        for (let i = 0; i < callsPerDay; i++) {
          const callId = `call-${callerIndex}-${day}-${i}`;
          const duration = Math.floor(Math.random() * 600) + 120; // 2-12 minutes
          const wasSuccessful = Math.random() > 0.25; // 75% success rate baseline
          
          sampleCalls.push({
            id: callId,
            callerId: caller.id,
            campaignId: campaign.id,
            duration,
            wasSuccessful,
            callDate: new Date(callDate.getTime() + i * 60000), // Spread calls throughout the day
            dialfireCallId: `df_call_${callId}`,
          });
        }
      }
    });
    
    sampleCalls.forEach(call => this.calls.set(call.id, call));
  }

  async getCampaign(id: string): Promise<Campaign | undefined> {
    return this.campaigns.get(id);
  }

  async getCampaignByDialfireId(dialfireId: string): Promise<Campaign | undefined> {
    return Array.from(this.campaigns.values()).find(c => c.dialfireId === dialfireId);
  }

  async createCampaign(insertCampaign: InsertCampaign): Promise<Campaign> {
    const id = randomUUID();
    const campaign: Campaign = { 
      ...insertCampaign, 
      id,
      isActive: insertCampaign.isActive ?? true,
      createdAt: new Date(),
    };
    this.campaigns.set(id, campaign);
    return campaign;
  }

  async getAllCampaigns(): Promise<Campaign[]> {
    return Array.from(this.campaigns.values());
  }

  async getTeam(id: string): Promise<Team | undefined> {
    return this.teams.get(id);
  }

  async getTeamByContactOwnerId(contactOwnerId: string): Promise<Team | undefined> {
    return Array.from(this.teams.values()).find(t => t.contactOwnerId === contactOwnerId);
  }

  async createTeam(insertTeam: InsertTeam): Promise<Team> {
    const id = randomUUID();
    const team: Team = { 
      ...insertTeam, 
      id,
      campaignId: insertTeam.campaignId ?? null,
    };
    this.teams.set(id, team);
    return team;
  }

  async getTeamsByCampaign(campaignId: string): Promise<Team[]> {
    return Array.from(this.teams.values()).filter(t => t.campaignId === campaignId);
  }

  async getAllTeams(): Promise<Team[]> {
    return Array.from(this.teams.values());
  }

  async getCaller(id: string): Promise<Caller | undefined> {
    return this.callers.get(id);
  }

  async getCallerByDialfireId(dialfireId: string): Promise<Caller | undefined> {
    return Array.from(this.callers.values()).find(c => c.dialfireId === dialfireId);
  }

  async createCaller(insertCaller: InsertCaller): Promise<Caller> {
    const id = randomUUID();
    const caller: Caller = { 
      ...insertCaller, 
      id,
      isActive: insertCaller.isActive ?? true,
      teamId: insertCaller.teamId ?? null,
    };
    this.callers.set(id, caller);
    return caller;
  }

  async getCallersByTeam(teamId: string): Promise<Caller[]> {
    return Array.from(this.callers.values()).filter(c => c.teamId === teamId);
  }

  async getAllCallers(): Promise<Caller[]> {
    return Array.from(this.callers.values());
  }

  async createCall(insertCall: InsertCall): Promise<Call> {
    const id = randomUUID();
    const call: Call = { 
      ...insertCall, 
      id,
      duration: insertCall.duration ?? null,
      campaignId: insertCall.campaignId ?? null,
      callerId: insertCall.callerId ?? null,
      wasSuccessful: insertCall.wasSuccessful ?? null,
      dialfireCallId: insertCall.dialfireCallId ?? null,
    };
    this.calls.set(id, call);
    return call;
  }

  async getCallsByCaller(callerId: string, startDate?: Date, endDate?: Date): Promise<Call[]> {
    let calls = Array.from(this.calls.values()).filter(c => c.callerId === callerId);
    
    if (startDate) {
      calls = calls.filter(c => c.callDate >= startDate);
    }
    if (endDate) {
      calls = calls.filter(c => c.callDate <= endDate);
    }
    
    return calls;
  }

  async getCallsByCampaign(campaignId: string, startDate?: Date, endDate?: Date): Promise<Call[]> {
    let calls = Array.from(this.calls.values()).filter(c => c.campaignId === campaignId);
    
    if (startDate) {
      calls = calls.filter(c => c.callDate >= startDate);
    }
    if (endDate) {
      calls = calls.filter(c => c.callDate <= endDate);
    }
    
    return calls;
  }

  async getCallsByTeam(teamId: string, startDate?: Date, endDate?: Date): Promise<Call[]> {
    const teamCallers = await this.getCallersByTeam(teamId);
    const callerIds = teamCallers.map(c => c.id);
    
    let calls = Array.from(this.calls.values()).filter(c => 
      c.callerId && callerIds.includes(c.callerId)
    );
    
    if (startDate) {
      calls = calls.filter(c => c.callDate >= startDate);
    }
    if (endDate) {
      calls = calls.filter(c => c.callDate <= endDate);
    }
    
    return calls;
  }

  async getThreshold(campaignId: string): Promise<Threshold | undefined> {
    return this.thresholds.get(campaignId);
  }

  async createThreshold(insertThreshold: InsertThreshold): Promise<Threshold> {
    const id = randomUUID();
    const threshold: Threshold = { 
      ...insertThreshold, 
      id,
      campaignId: insertThreshold.campaignId ?? null,
      minDailyCalls: insertThreshold.minDailyCalls ?? null,
      minSuccessRate: insertThreshold.minSuccessRate ?? null,
      minAvgDuration: insertThreshold.minAvgDuration ?? null,
      weeklyTarget: insertThreshold.weeklyTarget ?? null,
    };
    if (insertThreshold.campaignId) {
      this.thresholds.set(insertThreshold.campaignId, threshold);
    }
    return threshold;
  }

  async updateThreshold(campaignId: string, updates: Partial<InsertThreshold>): Promise<Threshold> {
    const existing = this.thresholds.get(campaignId);
    if (!existing) {
      throw new Error("Threshold not found");
    }
    
    const updated = { ...existing, ...updates };
    this.thresholds.set(campaignId, updated);
    return updated;
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const alert: Alert = { 
      ...insertAlert, 
      id,
      isActive: insertAlert.isActive ?? true,
      callerId: insertAlert.callerId ?? null,
      currentValue: insertAlert.currentValue ?? null,
      thresholdValue: insertAlert.thresholdValue ?? null,
      createdAt: new Date(),
    };
    this.alerts.set(id, alert);
    return alert;
  }

  async getActiveAlerts(campaignId?: string): Promise<Alert[]> {
    let alerts = Array.from(this.alerts.values()).filter(a => a.isActive);
    
    if (campaignId) {
      // Filter by campaign through caller relationship
      const campaignCallers = Array.from(this.callers.values())
        .filter(c => c.teamId && this.teams.get(c.teamId)?.campaignId === campaignId)
        .map(c => c.id);
      
      alerts = alerts.filter(a => a.callerId && campaignCallers.includes(a.callerId));
    }
    
    return alerts;
  }

  async dismissAlert(alertId: string): Promise<void> {
    const alert = this.alerts.get(alertId);
    if (alert) {
      alert.isActive = false;
      this.alerts.set(alertId, alert);
    }
  }

  async getDashboardStats(campaignId: string, startDate?: Date, endDate?: Date): Promise<DashboardStats> {
    const calls = await this.getCallsByCampaign(campaignId, startDate, endDate);
    const teams = await this.getTeamsByCampaign(campaignId);
    const campaignCallers = [];
    
    for (const team of teams) {
      const teamCallers = await this.getCallersByTeam(team.id);
      campaignCallers.push(...teamCallers);
    }

    const totalCalls = calls.length;
    const activeCallers = campaignCallers.filter(c => c.isActive).length;
    const successfulCalls = calls.filter(c => c.wasSuccessful).length;
    const successRate = totalCalls > 0 ? (successfulCalls / totalCalls) * 100 : 0;
    
    const avgDurationSeconds = calls.length > 0 
      ? calls.reduce((sum, c) => sum + (c.duration || 0), 0) / calls.length
      : 0;
    const avgDuration = `${Math.floor(avgDurationSeconds / 60)}:${String(Math.floor(avgDurationSeconds % 60)).padStart(2, '0')}`;

    // Generate calls over time (last 7 days)
    const callsOverTime = [];
    const today = new Date();
    for (let i = 6; i >= 0; i--) {
      const date = new Date(today);
      date.setDate(date.getDate() - i);
      const dateStr = date.toISOString().split('T')[0];
      const dayCalls = calls.filter(c => 
        c.callDate.toISOString().split('T')[0] === dateStr
      ).length;
      callsOverTime.push({ date: dateStr, calls: dayCalls });
    }

    // Team distribution
    const teamDistribution = [];
    for (const team of teams) {
      const teamCalls = await this.getCallsByTeam(team.id, startDate, endDate);
      teamDistribution.push({ team: team.name, calls: teamCalls.length });
    }

    return {
      totalCalls,
      activeCallers,
      avgDuration,
      successRate: Math.round(successRate * 10) / 10,
      callsOverTime,
      teamDistribution,
    };
  }

  async getCallerStats(campaignId: string, startDate?: Date, endDate?: Date): Promise<CallerStats[]> {
    const teams = await this.getTeamsByCampaign(campaignId);
    const stats: CallerStats[] = [];

    for (const team of teams) {
      const callers = await this.getCallersByTeam(team.id);
      
      for (const caller of callers) {
        const calls = await this.getCallsByCaller(caller.id, startDate, endDate);
        const successfulCalls = calls.filter(c => c.wasSuccessful);
        
        const totalCalls = calls.length;
        const successRate = totalCalls > 0 ? (successfulCalls.length / totalCalls) * 100 : 0;
        const avgDuration = totalCalls > 0 
          ? calls.reduce((sum, c) => sum + (c.duration || 0), 0) / totalCalls
          : 0;

        // Calculate daily and weekly calls
        const today = new Date();
        const todayCalls = calls.filter(c => 
          c.callDate.toDateString() === today.toDateString()
        ).length;

        const weekAgo = new Date(today);
        weekAgo.setDate(weekAgo.getDate() - 7);
        const weeklyCalls = calls.filter(c => c.callDate >= weekAgo).length;

        // Calculate trend (simplified)
        const trend = Math.random() * 20 - 10; // Random for now

        stats.push({
          caller,
          team,
          totalCalls,
          successfulCalls: successfulCalls.length,
          successRate: Math.round(successRate * 10) / 10,
          avgDuration: Math.round(avgDuration),
          dailyCalls: todayCalls,
          weeklyCalls,
          trend: Math.round(trend * 10) / 10,
        });
      }
    }

    return stats.sort((a, b) => b.totalCalls - a.totalCalls);
  }

  async getTeamStats(campaignId: string, startDate?: Date, endDate?: Date): Promise<TeamStats[]> {
    const teams = await this.getTeamsByCampaign(campaignId);
    const stats: TeamStats[] = [];

    for (const team of teams) {
      const calls = await this.getCallsByTeam(team.id, startDate, endDate);
      const callers = await this.getCallersByTeam(team.id);
      const successfulCalls = calls.filter(c => c.wasSuccessful);
      
      const totalCalls = calls.length;
      const memberCount = callers.length;
      const successRate = totalCalls > 0 ? (successfulCalls.length / totalCalls) * 100 : 0;
      const avgCallsPerMember = memberCount > 0 ? totalCalls / memberCount : 0;
      
      // Calculate trend (simplified)
      const trend = Math.random() * 20 - 5; // Random for now

      stats.push({
        team,
        totalCalls,
        memberCount,
        successRate: Math.round(successRate * 10) / 10,
        avgCallsPerMember: Math.round(avgCallsPerMember),
        trend: Math.round(trend * 10) / 10,
      });
    }

    return stats.sort((a, b) => b.totalCalls - a.totalCalls);
  }
}

export const storage = new MemStorage();
