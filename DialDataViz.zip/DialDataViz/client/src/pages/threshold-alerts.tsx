import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  AlertTriangle, 
  AlertCircle, 
  CheckCircle, 
  Settings, 
  Bell,
  Filter,
  Phone,
  TrendingUp,
  Clock,
  BarChart3,
  Lightbulb,
  Users,
  Calendar
} from "lucide-react";
import type { Alert as AlertType, Threshold, CallerStats } from "@shared/schema";

export default function ThresholdAlerts() {
  const { data: alerts, isLoading: isLoadingAlerts, error: alertsError } = useQuery<AlertType[]>({
    queryKey: ["/api/alerts/default-campaign"],
    refetchInterval: 30000, // Refresh every 30 seconds for alerts
  });

  const { data: threshold, isLoading: isLoadingThreshold, error: thresholdError } = useQuery<Threshold>({
    queryKey: ["/api/thresholds/default-campaign"],
    refetchInterval: 300000, // Refresh every 5 minutes
  });

  const { data: callerStats, isLoading: isLoadingCallers } = useQuery<CallerStats[]>({
    queryKey: ["/api/callers/stats/default-campaign"],
  });

  const error = alertsError || thresholdError;
  const isLoading = isLoadingAlerts || isLoadingThreshold;

  if (error) {
    return (
      <div className="p-6 md:p-8">
        <div className="text-center py-12">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">Failed to load threshold alerts</h3>
          <p className="text-muted-foreground">
            {error instanceof Error ? error.message : "An unexpected error occurred"}
          </p>
        </div>
      </div>
    );
  }

  // Generate mock alerts based on caller stats since we don't have real alert data
  const generateMockAlerts = () => {
    if (!callerStats || !threshold) return [];
    
    return callerStats
      .filter(stat => 
        stat.dailyCalls < (threshold.minDailyCalls || 50) ||
        stat.successRate < parseFloat(threshold.minSuccessRate || "70") ||
        stat.avgDuration < (threshold.minAvgDuration || 240) ||
        stat.weeklyCalls < (threshold.weeklyTarget || 350)
      )
      .map((stat, index) => {
        let alertType = "daily_calls";
        let currentValue = stat.dailyCalls;
        let thresholdValue = threshold.minDailyCalls || 50;
        let severity: "critical" | "warning" = "warning";

        if (stat.dailyCalls < (threshold.minDailyCalls || 50)) {
          alertType = "daily_calls";
          currentValue = stat.dailyCalls;
          thresholdValue = threshold.minDailyCalls || 50;
          severity = stat.dailyCalls < (threshold.minDailyCalls || 50) * 0.7 ? "critical" : "warning";
        } else if (stat.successRate < parseFloat(threshold.minSuccessRate || "70")) {
          alertType = "success_rate";
          currentValue = stat.successRate;
          thresholdValue = parseFloat(threshold.minSuccessRate || "70");
          severity = stat.successRate < parseFloat(threshold.minSuccessRate || "70") * 0.9 ? "critical" : "warning";
        } else if (stat.avgDuration < (threshold.minAvgDuration || 240)) {
          alertType = "avg_duration";
          currentValue = Math.round(stat.avgDuration / 60 * 100) / 100; // Convert to minutes
          thresholdValue = Math.round((threshold.minAvgDuration || 240) / 60 * 100) / 100;
          severity = "warning";
        } else if (stat.weeklyCalls < (threshold.weeklyTarget || 350)) {
          alertType = "weekly_target";
          currentValue = stat.weeklyCalls;
          thresholdValue = threshold.weeklyTarget || 350;
          severity = "warning";
        }

        return {
          id: `alert-${index}`,
          callerId: stat.caller.id,
          alertType,
          currentValue: currentValue.toString(),
          thresholdValue: thresholdValue.toString(),
          severity,
          isActive: true,
          createdAt: new Date(),
          caller: stat.caller,
          team: stat.team,
        };
      });
  };

  const mockAlerts = generateMockAlerts();
  const criticalAlerts = mockAlerts.filter(a => a.severity === "critical").length;
  const warningAlerts = mockAlerts.filter(a => a.severity === "warning").length;
  const onTrackCount = (callerStats?.length || 0) - mockAlerts.length;

  const getAlertIcon = (alertType: string) => {
    switch (alertType) {
      case "daily_calls": return Phone;
      case "success_rate": return TrendingUp;
      case "avg_duration": return Clock;
      case "weekly_target": return BarChart3;
      default: return AlertTriangle;
    }
  };

  const getAlertTypeLabel = (alertType: string) => {
    switch (alertType) {
      case "daily_calls": return "Daily Call Volume";
      case "success_rate": return "Success Rate";
      case "avg_duration": return "Avg Call Duration";
      case "weekly_target": return "Weekly Target";
      default: return "Alert";
    }
  };

  const formatAlertValue = (alertType: string, value: string) => {
    switch (alertType) {
      case "success_rate": return `${parseFloat(value).toFixed(1)}%`;
      case "avg_duration": return `${value}:00`;
      default: return value;
    }
  };

  return (
    <div className="page-section p-6 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-2">Threshold Alerts</h2>
            <p className="text-muted-foreground">Monitor callers performing below target thresholds</p>
          </div>
          
          <Button data-testid="configure-thresholds-button">
            <Settings className="h-4 w-4 mr-2" />
            Configure Thresholds
          </Button>
        </div>
      </div>

      {/* Current Thresholds */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Current Threshold Settings</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="p-4 bg-muted rounded-lg">
                  <Skeleton className="h-4 w-24 mb-2" />
                  <Skeleton className="h-8 w-16" />
                </div>
              ))}
            </div>
          ) : threshold ? (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="p-4 bg-muted rounded-lg" data-testid="min-daily-calls-threshold">
                <p className="text-sm text-muted-foreground mb-1">Minimum Daily Calls</p>
                <p className="stat-number text-2xl font-bold text-foreground">{threshold.minDailyCalls}</p>
              </div>
              <div className="p-4 bg-muted rounded-lg" data-testid="min-success-rate-threshold">
                <p className="text-sm text-muted-foreground mb-1">Minimum Success Rate</p>
                <p className="stat-number text-2xl font-bold text-foreground">{threshold.minSuccessRate}%</p>
              </div>
              <div className="p-4 bg-muted rounded-lg" data-testid="min-avg-duration-threshold">
                <p className="text-sm text-muted-foreground mb-1">Min Avg Duration</p>
                <p className="stat-number text-2xl font-bold text-foreground">
                  {Math.floor((threshold.minAvgDuration || 240) / 60)}:{String((threshold.minAvgDuration || 240) % 60).padStart(2, '0')}
                </p>
              </div>
              <div className="p-4 bg-muted rounded-lg" data-testid="weekly-target-threshold">
                <p className="text-sm text-muted-foreground mb-1">Weekly Target</p>
                <p className="stat-number text-2xl font-bold text-foreground">{threshold.weeklyTarget}</p>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              No threshold configuration found
            </div>
          )}
        </CardContent>
      </Card>

      {/* Alert Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="border-destructive/30">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-destructive/10 text-destructive w-12 h-12 rounded-lg flex items-center justify-center">
                <AlertCircle className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-foreground">Critical Alerts</h3>
            </div>
            {isLoadingCallers ? (
              <Skeleton className="h-8 w-8" />
            ) : (
              <p className="stat-number text-3xl font-bold text-destructive" data-testid="critical-alerts-count">
                {criticalAlerts}
              </p>
            )}
            <p className="text-xs text-muted-foreground mt-1">Require immediate attention</p>
          </CardContent>
        </Card>

        <Card className="border-chart-3/30">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-chart-3/10 text-chart-3 w-12 h-12 rounded-lg flex items-center justify-center">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-foreground">Warning Alerts</h3>
            </div>
            {isLoadingCallers ? (
              <Skeleton className="h-8 w-8" />
            ) : (
              <p className="stat-number text-3xl font-bold text-chart-3" data-testid="warning-alerts-count">
                {warningAlerts}
              </p>
            )}
            <p className="text-xs text-muted-foreground mt-1">Approaching threshold limits</p>
          </CardContent>
        </Card>

        <Card className="border-accent/30">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-accent/10 text-accent w-12 h-12 rounded-lg flex items-center justify-center">
                <CheckCircle className="h-6 w-6" />
              </div>
              <h3 className="font-semibold text-foreground">On Track</h3>
            </div>
            {isLoadingCallers ? (
              <Skeleton className="h-8 w-8" />
            ) : (
              <p className="stat-number text-3xl font-bold text-accent" data-testid="on-track-count">
                {onTrackCount}
              </p>
            )}
            <p className="text-xs text-muted-foreground mt-1">Meeting all thresholds</p>
          </CardContent>
        </Card>
      </div>

      {/* Alert Details Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Active Alerts</CardTitle>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" data-testid="filter-alerts">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Button size="sm" data-testid="send-notifications">
                <Bell className="h-4 w-4 mr-2" />
                Send Notifications
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Caller</th>
                  <th>Team</th>
                  <th>Alert Type</th>
                  <th>Current Value</th>
                  <th>Threshold</th>
                  <th>Gap</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i}>
                      <td>
                        <div className="flex items-center gap-3">
                          <Skeleton className="w-8 h-8 rounded-full" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                      </td>
                      <td><Skeleton className="h-4 w-16" /></td>
                      <td><Skeleton className="h-4 w-20" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                      <td><Skeleton className="h-6 w-16 rounded-full" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                    </tr>
                  ))
                ) : mockAlerts.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-muted-foreground">
                      <CheckCircle className="h-8 w-8 mx-auto mb-2 text-accent" />
                      No active alerts - all callers meeting thresholds
                    </td>
                  </tr>
                ) : (
                  mockAlerts.map((alert) => {
                    const AlertIcon = getAlertIcon(alert.alertType);
                    const initials = alert.caller.name
                      .split(' ')
                      .map(n => n[0])
                      .join('')
                      .toUpperCase()
                      .slice(0, 2);
                    
                    const gap = parseFloat(alert.currentValue) - parseFloat(alert.thresholdValue);
                    const gapDisplay = alert.alertType === "success_rate" || alert.alertType === "avg_duration"
                      ? gap.toFixed(1)
                      : Math.round(gap).toString();

                    return (
                      <tr key={alert.id} data-testid={`alert-row-${alert.id}`}>
                        <td>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-semibold">
                              {initials}
                            </div>
                            <span className="font-medium text-foreground">{alert.caller.name}</span>
                          </div>
                        </td>
                        <td className="text-muted-foreground">{alert.team.name}</td>
                        <td>
                          <div className="flex items-center gap-2">
                            <AlertIcon className={`h-4 w-4 ${alert.severity === 'critical' ? 'text-destructive' : 'text-chart-3'}`} />
                            <span className="text-sm text-foreground">{getAlertTypeLabel(alert.alertType)}</span>
                          </div>
                        </td>
                        <td className="stat-number text-foreground font-semibold">
                          {formatAlertValue(alert.alertType, alert.currentValue)}
                        </td>
                        <td className="stat-number text-muted-foreground">
                          {formatAlertValue(alert.alertType, alert.thresholdValue)}
                        </td>
                        <td className={`stat-number font-semibold ${alert.severity === 'critical' ? 'text-destructive' : 'text-chart-3'}`}>
                          {gapDisplay.startsWith('-') ? gapDisplay : `-${gapDisplay}`}
                          {alert.alertType === "success_rate" && "%"}
                          {alert.alertType === "avg_duration" && ":00"}
                        </td>
                        <td>
                          <Badge className={alert.severity === 'critical' ? 'badge-danger' : 'badge-warning'}>
                            {alert.severity === 'critical' ? 'Critical' : 'Warning'}
                          </Badge>
                        </td>
                        <td>
                          <Button variant="link" className="text-primary hover:text-primary/80 p-0 h-auto" data-testid={`review-alert-${alert.id}`}>
                            Review
                          </Button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Action Recommendations */}
      <Card className="mt-8">
        <CardHeader>
          <CardTitle>Recommended Actions</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-start gap-3 p-4 border border-border rounded-lg">
                  <Skeleton className="h-4 w-4 mt-1" />
                  <div className="flex-1">
                    <Skeleton className="h-5 w-32 mb-2" />
                    <Skeleton className="h-4 w-full" />
                  </div>
                  <Skeleton className="h-6 w-16" />
                </div>
              ))}
            </div>
          ) : criticalAlerts > 0 ? (
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-4 bg-destructive/5 border border-destructive/20 rounded-lg">
                <Lightbulb className="h-4 w-4 text-destructive mt-1" />
                <div className="flex-1">
                  <p className="font-medium text-foreground mb-1">Schedule Training Session</p>
                  <p className="text-sm text-muted-foreground">
                    Callers with critical alerts would benefit from additional coaching on call techniques and success strategies.
                  </p>
                </div>
                <Button variant="link" className="text-primary font-medium p-0 h-auto" data-testid="schedule-training">
                  Schedule
                </Button>
              </div>

              {warningAlerts > 2 && (
                <div className="flex items-start gap-3 p-4 bg-chart-3/5 border border-chart-3/20 rounded-lg">
                  <Users className="h-4 w-4 text-chart-3 mt-1" />
                  <div className="flex-1">
                    <p className="font-medium text-foreground mb-1">Team Review Meeting</p>
                    <p className="text-sm text-muted-foreground">
                      Multiple team members showing warning alerts. Consider a team performance review to identify systematic issues.
                    </p>
                  </div>
                  <Button variant="link" className="text-primary font-medium p-0 h-auto" data-testid="create-meeting">
                    Create Meeting
                  </Button>
                </div>
              )}

              <div className="flex items-start gap-3 p-4 bg-primary/5 border border-primary/20 rounded-lg">
                <Bell className="h-4 w-4 text-primary mt-1" />
                <div className="flex-1">
                  <p className="font-medium text-foreground mb-1">Enable Auto-Notifications</p>
                  <p className="text-sm text-muted-foreground">
                    Set up automatic alerts when callers fall below threshold to enable faster intervention.
                  </p>
                </div>
                <Button variant="link" className="text-primary font-medium p-0 h-auto" data-testid="configure-notifications">
                  Configure
                </Button>
              </div>
            </div>
          ) : (
            <div className="text-center py-8">
              <CheckCircle className="h-12 w-12 text-accent mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">All Systems Performing Well</h3>
              <p className="text-muted-foreground">No immediate actions required. All callers are meeting their performance thresholds.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
