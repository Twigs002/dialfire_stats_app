import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import CallsOverTimeChart from "@/components/charts/calls-over-time";
import TeamDistributionChart from "@/components/charts/team-distribution";
import { Phone, Users, Clock, TrendingUp, CheckCircle, Trophy, AlertTriangle } from "lucide-react";
import type { DashboardStats } from "@shared/schema";

export default function Overview() {
  const { data: stats, isLoading, error } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats/default-campaign"],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  if (error) {
    return (
      <div className="p-6 md:p-8">
        <div className="text-center py-12">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">Failed to load dashboard data</h3>
          <p className="text-muted-foreground">
            {error instanceof Error ? error.message : "An unexpected error occurred"}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="page-section p-6 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Campaign Overview</h2>
        <p className="text-muted-foreground">Monitor key metrics and performance indicators across your campaigns</p>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-primary/10 text-primary w-12 h-12 rounded-lg flex items-center justify-center">
                <Phone className="h-6 w-6" />
              </div>
              <Badge variant="secondary" className="text-accent">
                <TrendingUp className="h-3 w-3 mr-1" />
                12.5%
              </Badge>
            </div>
            <p className="text-muted-foreground text-sm mb-1">Total Calls Today</p>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <p className="stat-number text-3xl font-bold text-foreground" data-testid="total-calls">
                {stats?.totalCalls.toLocaleString() || "0"}
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-accent/10 text-accent w-12 h-12 rounded-lg flex items-center justify-center">
                <Users className="h-6 w-6" />
              </div>
              <Badge variant="secondary" className="text-accent">
                <TrendingUp className="h-3 w-3 mr-1" />
                5.2%
              </Badge>
            </div>
            <p className="text-muted-foreground text-sm mb-1">Active Callers</p>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <p className="stat-number text-3xl font-bold text-foreground" data-testid="active-callers">
                {stats?.activeCallers || "0"}
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-chart-2/10 text-chart-2 w-12 h-12 rounded-lg flex items-center justify-center">
                <Clock className="h-6 w-6" />
              </div>
              <Badge variant="secondary" className="text-muted-foreground">
                ~
              </Badge>
            </div>
            <p className="text-muted-foreground text-sm mb-1">Avg Call Duration</p>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <p className="stat-number text-3xl font-bold text-foreground" data-testid="avg-duration">
                {stats?.avgDuration || "0:00"}
              </p>
            )}
          </CardContent>
        </Card>

        <Card className="stat-card">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="bg-chart-3/10 text-chart-3 w-12 h-12 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-6 w-6" />
              </div>
              <Badge variant="secondary" className="text-accent">
                <TrendingUp className="h-3 w-3 mr-1" />
                8.1%
              </Badge>
            </div>
            <p className="text-muted-foreground text-sm mb-1">Success Rate</p>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <p className="stat-number text-3xl font-bold text-foreground" data-testid="success-rate">
                {stats?.successRate.toFixed(1)}%
              </p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Calls Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="chart-container">
              {isLoading ? (
                <Skeleton className="h-full w-full" />
              ) : (
                <CallsOverTimeChart data={stats?.callsOverTime || []} />
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Team Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="chart-container">
              {isLoading ? (
                <Skeleton className="h-full w-full" />
              ) : (
                <TeamDistributionChart data={stats?.teamDistribution || []} />
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {isLoading ? (
              Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="flex items-center gap-4 p-3">
                  <Skeleton className="h-10 w-10 rounded-full" />
                  <div className="flex-1">
                    <Skeleton className="h-4 w-48 mb-2" />
                    <Skeleton className="h-3 w-32" />
                  </div>
                  <Skeleton className="h-6 w-16 rounded-full" />
                </div>
              ))
            ) : (
              <>
                <div className="flex items-center gap-4 p-3 hover:bg-muted rounded-lg transition-colors">
                  <div className="bg-primary/10 text-primary w-10 h-10 rounded-full flex items-center justify-center">
                    <Phone className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">System synchronized call data</p>
                    <p className="text-xs text-muted-foreground">Campaign #001 • Just now</p>
                  </div>
                  <Badge className="badge-success">Success</Badge>
                </div>

                <div className="flex items-center gap-4 p-3 hover:bg-muted rounded-lg transition-colors">
                  <div className="bg-accent/10 text-accent w-10 h-10 rounded-full flex items-center justify-center">
                    <Trophy className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">Daily targets being monitored</p>
                    <p className="text-xs text-muted-foreground">All teams • 5 minutes ago</p>
                  </div>
                  <Badge className="badge-success">Active</Badge>
                </div>

                <div className="flex items-center gap-4 p-3 hover:bg-muted rounded-lg transition-colors">
                  <div className="bg-chart-3/10 text-chart-3 w-10 h-10 rounded-full flex items-center justify-center">
                    <AlertTriangle className="h-4 w-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground">Threshold alerts configured</p>
                    <p className="text-xs text-muted-foreground">System • 10 minutes ago</p>
                  </div>
                  <Badge className="badge-warning">Ready</Badge>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
