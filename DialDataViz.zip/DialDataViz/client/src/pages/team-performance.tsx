import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Info, Users, Shield, Crown, TrendingUp, TrendingDown, AlertTriangle } from "lucide-react";
import type { TeamStats, CallerStats } from "@shared/schema";

export default function TeamPerformance() {
  const { data: teamStats, isLoading: isLoadingTeams, error: teamsError } = useQuery<TeamStats[]>({
    queryKey: ["/api/teams/stats/default-campaign"],
    refetchInterval: 60000,
  });

  const { data: callerStats, isLoading: isLoadingCallers, error: callersError } = useQuery<CallerStats[]>({
    queryKey: ["/api/callers/stats/default-campaign"],
    refetchInterval: 60000,
  });

  const error = teamsError || callersError;
  const isLoading = isLoadingTeams || isLoadingCallers;

  if (error) {
    return (
      <div className="p-6 md:p-8">
        <div className="text-center py-12">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">Failed to load team performance data</h3>
          <p className="text-muted-foreground">
            {error instanceof Error ? error.message : "An unexpected error occurred"}
          </p>
        </div>
      </div>
    );
  }

  const teamIcons = {
    "Assassins": Shield,
    "Warriors": Users,
    "Titans": Crown,
  };

  return (
    <div className="page-section p-6 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Team Performance</h2>
        <p className="text-muted-foreground">Monitor performance across teams with custom contact owner mapping</p>
      </div>

      {/* Team Mapping Info Card */}
      <Alert className="mb-8 border-primary/20 bg-primary/5">
        <Info className="h-4 w-4 text-primary" />
        <AlertDescription className="text-foreground">
          <p className="font-medium mb-1">Team ID Mapping Configuration</p>
          <p className="text-sm text-muted-foreground">
            Contact Owner IDs are mapped to team names: 1234 → Assassins, 5678 → Warriors, 9012 → Titans
          </p>
          <Button variant="link" className="p-0 h-auto text-primary font-medium mt-2" data-testid="edit-team-mapping">
            Edit Team Mapping
          </Button>
        </AlertDescription>
      </Alert>

      {/* Team Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <Skeleton className="w-12 h-12 rounded-lg" />
                    <div>
                      <Skeleton className="h-5 w-20 mb-1" />
                      <Skeleton className="h-3 w-16" />
                    </div>
                  </div>
                  <Skeleton className="h-6 w-16 rounded-full" />
                </div>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-16" />
                    <Skeleton className="h-4 w-12" />
                  </div>
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-20" />
                    <Skeleton className="h-4 w-8" />
                  </div>
                  <div className="flex items-center justify-between">
                    <Skeleton className="h-4 w-18" />
                    <Skeleton className="h-4 w-12" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : teamStats?.length === 0 ? (
          <div className="col-span-3 text-center py-12">
            <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">No team data available</h3>
            <p className="text-muted-foreground">Team performance data will appear here once calls are logged</p>
          </div>
        ) : (
          teamStats?.map((stat) => {
            const IconComponent = teamIcons[stat.team.name as keyof typeof teamIcons] || Users;
            const statusVariant = stat.successRate >= 70 ? "badge-success" : "badge-warning";
            const statusText = stat.successRate >= 70 ? "Active" : "Review";
            
            return (
              <Card key={stat.team.id} data-testid={`team-card-${stat.team.name.toLowerCase()}`}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="bg-primary/10 text-primary w-12 h-12 rounded-lg flex items-center justify-center">
                        <IconComponent className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground">{stat.team.name}</h3>
                        <p className="text-xs text-muted-foreground">ID: {stat.team.contactOwnerId}</p>
                      </div>
                    </div>
                    <Badge className={statusVariant}>{statusText}</Badge>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Total Calls</span>
                      <span className="stat-number font-semibold text-foreground">{stat.totalCalls.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Team Members</span>
                      <span className="stat-number font-semibold text-foreground">{stat.memberCount}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Success Rate</span>
                      <span className="stat-number font-semibold text-accent">{stat.successRate.toFixed(1)}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        )}
      </div>

      {/* Detailed Team Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle>Team Member Breakdown</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Team Member</th>
                  <th>Team</th>
                  <th>Contact Owner ID</th>
                  <th>Calls Made</th>
                  <th>Success Rate</th>
                  <th>Performance</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i}>
                      <td>
                        <div className="flex items-center gap-3">
                          <Skeleton className="w-8 h-8 rounded-full" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                      </td>
                      <td><Skeleton className="h-6 w-20 rounded-full" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                      <td><Skeleton className="h-4 w-16" /></td>
                    </tr>
                  ))
                ) : callerStats?.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="text-center py-8 text-muted-foreground">
                      No caller data available
                    </td>
                  </tr>
                ) : (
                  callerStats?.map((stat) => {
                    const initials = stat.caller.name
                      .split(' ')
                      .map(n => n[0])
                      .join('')
                      .toUpperCase()
                      .slice(0, 2);
                    
                    const teamColor = stat.team.name === "Assassins" 
                      ? "hsl(221.2 83.2% 95%)" 
                      : stat.team.name === "Warriors" 
                      ? "hsl(142.1 76.2% 95%)" 
                      : "hsl(280.4 89% 95%)";
                    
                    const teamTextColor = stat.team.name === "Assassins" 
                      ? "hsl(221.2 83.2% 40%)" 
                      : stat.team.name === "Warriors" 
                      ? "hsl(142.1 76.2% 30%)" 
                      : "hsl(280.4 89% 40%)";

                    return (
                      <tr key={stat.caller.id} data-testid={`member-row-${stat.caller.id}`}>
                        <td>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-semibold">
                              {initials}
                            </div>
                            <span className="font-medium text-foreground">{stat.caller.name}</span>
                          </div>
                        </td>
                        <td>
                          <Badge 
                            className="badge"
                            style={{ backgroundColor: teamColor, color: teamTextColor }}
                          >
                            {stat.team.name}
                          </Badge>
                        </td>
                        <td className="stat-number text-muted-foreground">{stat.team.contactOwnerId}</td>
                        <td className="stat-number text-foreground font-semibold">{stat.totalCalls}</td>
                        <td className="stat-number text-foreground">{stat.successRate.toFixed(1)}%</td>
                        <td>
                          <div className="flex items-center gap-2">
                            {stat.trend >= 0 ? (
                              <TrendingUp className="h-3 w-3 text-accent" />
                            ) : (
                              <TrendingDown className="h-3 w-3 text-destructive" />
                            )}
                            <span className={`text-sm font-medium ${stat.trend >= 0 ? 'text-accent' : 'text-destructive'}`}>
                              {stat.trend >= 0 ? '+' : ''}{stat.trend.toFixed(1)}%
                            </span>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
