import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, Phone, UserCheck, TrendingUp, Search, Download, AlertTriangle } from "lucide-react";
import type { CallerStats } from "@shared/schema";

export default function CallerStats() {
  const [startDate, setStartDate] = useState(new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [searchTerm, setSearchTerm] = useState("");

  const { data: callerStats, isLoading, error } = useQuery<CallerStats[]>({
    queryKey: ["/api/callers/stats/default-campaign", { startDate, endDate }],
    refetchInterval: 60000, // Refresh every minute
  });

  const filteredStats = callerStats?.filter(stat =>
    stat.caller.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    stat.team.name.toLowerCase().includes(searchTerm.toLowerCase())
  ) || [];

  const applyDateFilter = () => {
    // Query will automatically refetch due to dependency on startDate/endDate
  };

  if (error) {
    return (
      <div className="p-6 md:p-8">
        <div className="text-center py-12">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">Failed to load caller statistics</h3>
          <p className="text-muted-foreground">
            {error instanceof Error ? error.message : "An unexpected error occurred"}
          </p>
        </div>
      </div>
    );
  }

  const totalCalls = filteredStats.reduce((sum, stat) => sum + stat.totalCalls, 0);
  const topPerformer = filteredStats.length > 0 ? filteredStats[0] : null;
  const avgPerCaller = filteredStats.length > 0 ? Math.round(totalCalls / filteredStats.length) : 0;

  return (
    <div className="page-section p-6 md:p-8">
      {/* Header with Date Range */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-2">Caller Statistics</h2>
            <p className="text-muted-foreground">View detailed call logs per caller with custom date ranges</p>
          </div>

          {/* Date Range Picker */}
          <div className="flex items-center gap-3 bg-card border border-border rounded-lg p-3 shadow-sm">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <Input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="bg-transparent text-sm border-none p-0 h-auto focus-visible:ring-0"
              data-testid="start-date-input"
            />
            <span className="text-muted-foreground">to</span>
            <Input
              type="date"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
              className="bg-transparent text-sm border-none p-0 h-auto focus-visible:ring-0"
              data-testid="end-date-input"
            />
            <Button 
              onClick={applyDateFilter}
              size="sm"
              data-testid="apply-date-filter"
            >
              Apply
            </Button>
          </div>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-primary/10 text-primary w-10 h-10 rounded-lg flex items-center justify-center">
                <Phone className="h-5 w-5" />
              </div>
              <h3 className="font-semibold text-foreground">Total Calls</h3>
            </div>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <p className="stat-number text-2xl font-bold text-foreground" data-testid="summary-total-calls">
                {totalCalls.toLocaleString()}
              </p>
            )}
            <p className="text-xs text-muted-foreground mt-1">In selected date range</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-accent/10 text-accent w-10 h-10 rounded-lg flex items-center justify-center">
                <UserCheck className="h-5 w-5" />
              </div>
              <h3 className="font-semibold text-foreground">Top Performer</h3>
            </div>
            {isLoading ? (
              <Skeleton className="h-6 w-24" />
            ) : (
              <p className="text-xl font-semibold text-foreground" data-testid="top-performer-name">
                {topPerformer?.caller.name || "N/A"}
              </p>
            )}
            <p className="text-xs text-muted-foreground mt-1">
              {topPerformer ? `${topPerformer.totalCalls} calls logged` : "No data available"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-3">
              <div className="bg-chart-2/10 text-chart-2 w-10 h-10 rounded-lg flex items-center justify-center">
                <TrendingUp className="h-5 w-5" />
              </div>
              <h3 className="font-semibold text-foreground">Average Per Caller</h3>
            </div>
            {isLoading ? (
              <Skeleton className="h-8 w-20" />
            ) : (
              <p className="stat-number text-2xl font-bold text-foreground" data-testid="avg-per-caller">
                {avgPerCaller}
              </p>
            )}
            <p className="text-xs text-muted-foreground mt-1">Calls per person</p>
          </CardContent>
        </Card>
      </div>

      {/* Caller Performance Table */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Caller Performance Details</CardTitle>
            <div className="flex items-center gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search callers..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="search-callers"
                />
              </div>
              <Button variant="outline" size="sm" data-testid="export-data">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Caller Name</th>
                  <th>Team</th>
                  <th>Total Calls</th>
                  <th>Successful</th>
                  <th>Success Rate</th>
                  <th>Avg Duration</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {isLoading ? (
                  Array.from({ length: 5 }).map((_, i) => (
                    <tr key={i}>
                      <td>
                        <div className="flex items-center gap-3">
                          <Skeleton className="w-8 h-8 rounded-full" />
                          <Skeleton className="h-4 w-24" />
                        </div>
                      </td>
                      <td><Skeleton className="h-4 w-16" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                      <td><Skeleton className="h-4 w-16" /></td>
                      <td><Skeleton className="h-4 w-12" /></td>
                      <td><Skeleton className="h-6 w-20 rounded-full" /></td>
                    </tr>
                  ))
                ) : filteredStats.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="text-center py-8 text-muted-foreground">
                      No caller data available for the selected date range
                    </td>
                  </tr>
                ) : (
                  filteredStats.map((stat) => {
                    const initials = stat.caller.name
                      .split(' ')
                      .map(n => n[0])
                      .join('')
                      .toUpperCase()
                      .slice(0, 2);
                    
                    const statusBadge = stat.successRate >= 70 
                      ? "badge-success" 
                      : stat.successRate >= 60 
                      ? "badge-warning" 
                      : "badge-danger";
                    
                    const statusText = stat.successRate >= 70 
                      ? "On Target" 
                      : stat.successRate >= 60 
                      ? "Below Target" 
                      : "Critical";
                    
                    const durationMinutes = Math.floor(stat.avgDuration / 60);
                    const durationSeconds = stat.avgDuration % 60;
                    const durationDisplay = `${durationMinutes}:${durationSeconds.toString().padStart(2, '0')}`;

                    return (
                      <tr key={stat.caller.id} data-testid={`caller-row-${stat.caller.id}`}>
                        <td>
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center text-xs font-semibold">
                              {initials}
                            </div>
                            <span className="font-medium text-foreground">{stat.caller.name}</span>
                          </div>
                        </td>
                        <td className="text-muted-foreground">{stat.team.name}</td>
                        <td className="stat-number text-foreground font-semibold">{stat.totalCalls}</td>
                        <td className="stat-number text-foreground">{stat.successfulCalls}</td>
                        <td>
                          <div className="flex items-center gap-2">
                            <div className="flex-1 bg-muted rounded-full h-2 overflow-hidden">
                              <div 
                                className="bg-accent h-full" 
                                style={{ width: `${Math.min(stat.successRate, 100)}%` }}
                              />
                            </div>
                            <span className="stat-number text-sm text-foreground">{stat.successRate.toFixed(1)}%</span>
                          </div>
                        </td>
                        <td className="stat-number text-muted-foreground">{durationDisplay}</td>
                        <td>
                          <Badge className={statusBadge}>{statusText}</Badge>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          {!isLoading && filteredStats.length > 0 && (
            <div className="p-4 border-t border-border flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                Showing {filteredStats.length} callers
              </p>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" disabled>Previous</Button>
                <Button size="sm">1</Button>
                <Button variant="outline" size="sm" disabled>Next</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
