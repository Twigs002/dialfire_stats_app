import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import PerformanceComparisonCharts from "@/components/charts/performance-comparison";
import { Users, BarChart3, Trophy, TrendingUp, AlertCircle, AlertTriangle } from "lucide-react";
import type { CallerStats, TeamStats } from "@shared/schema";

export default function PerformanceComparison() {
  const [comparisonType, setComparisonType] = useState<'callers' | 'teams'>('callers');

  const { data: callerStats, isLoading: isLoadingCallers, error: callersError } = useQuery<CallerStats[]>({
    queryKey: ["/api/callers/stats/default-campaign"],
    refetchInterval: 60000,
  });

  const { data: teamStats, isLoading: isLoadingTeams, error: teamsError } = useQuery<TeamStats[]>({
    queryKey: ["/api/teams/stats/default-campaign"],
    refetchInterval: 60000,
  });

  const error = callersError || teamsError;
  const isLoading = isLoadingCallers || isLoadingTeams;

  if (error) {
    return (
      <div className="p-6 md:p-8">
        <div className="text-center py-12">
          <AlertTriangle className="h-12 w-12 text-destructive mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-foreground mb-2">Failed to load performance comparison data</h3>
          <p className="text-muted-foreground">
            {error instanceof Error ? error.message : "An unexpected error occurred"}
          </p>
        </div>
      </div>
    );
  }

  // Calculate insights
  const getInsights = () => {
    if (!callerStats || !teamStats) return null;

    const topCaller = callerStats[0];
    const trendingTeam = teamStats.find(team => team.trend > 10);
    const needsAttentionTeam = teamStats.find(team => team.successRate < 70);

    return {
      topPerformer: topCaller,
      trendingUp: trendingTeam,
      needsAttention: needsAttentionTeam,
    };
  };

  const insights = getInsights();

  return (
    <div className="page-section p-6 md:p-8">
      {/* Header */}
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Performance Comparison</h2>
        <p className="text-muted-foreground">Interactive graphs comparing callers and team performance metrics</p>
      </div>

      {/* Comparison Type Selector */}
      <Card className="mb-8">
        <CardContent className="p-4">
          <div className="flex items-center gap-4">
            <span className="text-sm font-medium text-foreground">Compare by:</span>
            <div className="flex gap-2">
              <Button
                variant={comparisonType === 'callers' ? 'default' : 'outline'}
                onClick={() => setComparisonType('callers')}
                data-testid="compare-callers-button"
              >
                <Users className="h-4 w-4 mr-2" />
                Individual Callers
              </Button>
              <Button
                variant={comparisonType === 'teams' ? 'default' : 'outline'}
                onClick={() => setComparisonType('teams')}
                data-testid="compare-teams-button"
              >
                <BarChart3 className="h-4 w-4 mr-2" />
                Teams
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Charts Section */}
      {isLoading ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {Array.from({ length: 4 }).map((_, i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-48" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-[300px] w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <PerformanceComparisonCharts 
          comparisonType={comparisonType}
          callerStats={callerStats || []}
          teamStats={teamStats || []}
        />
      )}

      {/* Performance Insights */}
      <Card>
        <CardHeader>
          <CardTitle>Performance Insights</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {Array.from({ length: 3 }).map((_, i) => (
                <div key={i} className="p-4 border border-border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <Skeleton className="h-4 w-4" />
                    <Skeleton className="h-5 w-24" />
                  </div>
                  <Skeleton className="h-4 w-full" />
                </div>
              ))}
            </div>
          ) : insights ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-accent/5 border border-accent/20 rounded-lg" data-testid="top-performer-insight">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="h-4 w-4 text-accent" />
                  <h4 className="font-semibold text-foreground">Top Performer</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  {insights.topPerformer 
                    ? `${insights.topPerformer.caller.name} leads with ${insights.topPerformer.totalCalls} calls and ${insights.topPerformer.successRate.toFixed(1)}% success rate`
                    : "No caller data available"
                  }
                </p>
              </div>

              <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg" data-testid="trending-up-insight">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-primary" />
                  <h4 className="font-semibold text-foreground">Trending Up</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  {insights.trendingUp 
                    ? `${insights.trendingUp.team.name} team showing ${insights.trendingUp.trend.toFixed(1)}% improvement`
                    : "All teams maintaining steady performance"
                  }
                </p>
              </div>

              <div className="p-4 bg-chart-3/5 border border-chart-3/20 rounded-lg" data-testid="needs-attention-insight">
                <div className="flex items-center gap-2 mb-2">
                  <AlertCircle className="h-4 w-4 text-chart-3" />
                  <h4 className="font-semibold text-foreground">Needs Attention</h4>
                </div>
                <p className="text-sm text-muted-foreground">
                  {insights.needsAttention 
                    ? `${insights.needsAttention.team.name} team average below target at ${insights.needsAttention.successRate.toFixed(1)}%`
                    : "All teams meeting performance targets"
                  }
                </p>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              No performance data available for insights
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
