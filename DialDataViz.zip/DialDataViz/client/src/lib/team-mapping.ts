// Team Mapping Utility
// Manages the mapping between DialFire Contact Owner IDs and team names

export interface TeamMapping {
  contactOwnerId: string;
  teamName: string;
  description?: string;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface CreateTeamMappingRequest {
  contactOwnerId: string;
  teamName: string;
  description?: string;
}

// Default team mappings as specified in requirements
const DEFAULT_TEAM_MAPPINGS: Omit<TeamMapping, 'createdAt' | 'updatedAt'>[] = [
  {
    contactOwnerId: "1234",
    teamName: "Assassins",
    description: "High-performance call team specializing in complex campaigns",
    isActive: true,
  },
  {
    contactOwnerId: "5678",
    teamName: "Warriors",
    description: "Strategic call team focused on relationship building",
    isActive: true,
  },
  {
    contactOwnerId: "9012",
    teamName: "Titans",
    description: "Volume-focused call team for large-scale campaigns",
    isActive: true,
  },
];

class TeamMappingService {
  private mappings: Map<string, TeamMapping> = new Map();
  private localStorageKey = 'dialfire-team-mappings';

  constructor() {
    this.loadFromLocalStorage();
    this.ensureDefaultMappings();
  }

  // Load mappings from localStorage
  private loadFromLocalStorage() {
    try {
      const stored = localStorage.getItem(this.localStorageKey);
      if (stored) {
        const mappings: TeamMapping[] = JSON.parse(stored);
        mappings.forEach(mapping => {
          // Convert date strings back to Date objects
          mapping.createdAt = new Date(mapping.createdAt);
          mapping.updatedAt = new Date(mapping.updatedAt);
          this.mappings.set(mapping.contactOwnerId, mapping);
        });
      }
    } catch (error) {
      console.warn('Failed to load team mappings from localStorage:', error);
    }
  }

  // Save mappings to localStorage
  private saveToLocalStorage() {
    try {
      const mappingsArray = Array.from(this.mappings.values());
      localStorage.setItem(this.localStorageKey, JSON.stringify(mappingsArray));
    } catch (error) {
      console.error('Failed to save team mappings to localStorage:', error);
    }
  }

  // Ensure default mappings exist
  private ensureDefaultMappings() {
    const now = new Date();
    
    DEFAULT_TEAM_MAPPINGS.forEach(defaultMapping => {
      if (!this.mappings.has(defaultMapping.contactOwnerId)) {
        const mapping: TeamMapping = {
          ...defaultMapping,
          createdAt: now,
          updatedAt: now,
        };
        this.mappings.set(mapping.contactOwnerId, mapping);
      }
    });

    this.saveToLocalStorage();
  }

  // Get team name by contact owner ID
  getTeamName(contactOwnerId: string): string {
    const mapping = this.mappings.get(contactOwnerId);
    return mapping?.isActive ? mapping.teamName : `Team ${contactOwnerId}`;
  }

  // Get team mapping by contact owner ID
  getTeamMapping(contactOwnerId: string): TeamMapping | undefined {
    return this.mappings.get(contactOwnerId);
  }

  // Get all team mappings
  getAllMappings(): TeamMapping[] {
    return Array.from(this.mappings.values()).filter(mapping => mapping.isActive);
  }

  // Get all mappings including inactive ones
  getAllMappingsIncludingInactive(): TeamMapping[] {
    return Array.from(this.mappings.values());
  }

  // Create or update team mapping
  setTeamMapping(request: CreateTeamMappingRequest): TeamMapping {
    const now = new Date();
    const existingMapping = this.mappings.get(request.contactOwnerId);

    const mapping: TeamMapping = {
      contactOwnerId: request.contactOwnerId,
      teamName: request.teamName,
      description: request.description,
      isActive: true,
      createdAt: existingMapping?.createdAt || now,
      updatedAt: now,
    };

    this.mappings.set(request.contactOwnerId, mapping);
    this.saveToLocalStorage();

    return mapping;
  }

  // Update team mapping
  updateTeamMapping(
    contactOwnerId: string, 
    updates: Partial<Pick<TeamMapping, 'teamName' | 'description' | 'isActive'>>
  ): TeamMapping | null {
    const existingMapping = this.mappings.get(contactOwnerId);
    if (!existingMapping) {
      return null;
    }

    const updatedMapping: TeamMapping = {
      ...existingMapping,
      ...updates,
      updatedAt: new Date(),
    };

    this.mappings.set(contactOwnerId, updatedMapping);
    this.saveToLocalStorage();

    return updatedMapping;
  }

  // Delete team mapping (mark as inactive)
  deleteTeamMapping(contactOwnerId: string): boolean {
    const mapping = this.mappings.get(contactOwnerId);
    if (mapping) {
      mapping.isActive = false;
      mapping.updatedAt = new Date();
      this.saveToLocalStorage();
      return true;
    }
    return false;
  }

  // Permanently remove team mapping
  removeTeamMapping(contactOwnerId: string): boolean {
    const removed = this.mappings.delete(contactOwnerId);
    if (removed) {
      this.saveToLocalStorage();
    }
    return removed;
  }

  // Get team statistics
  getTeamStats(): Array<{
    contactOwnerId: string;
    teamName: string;
    memberCount: number;
    isActive: boolean;
  }> {
    return Array.from(this.mappings.values()).map(mapping => ({
      contactOwnerId: mapping.contactOwnerId,
      teamName: mapping.teamName,
      memberCount: 0, // This would be calculated from actual caller data
      isActive: mapping.isActive,
    }));
  }

  // Validate contact owner ID format
  isValidContactOwnerId(contactOwnerId: string): boolean {
    // Basic validation - adjust as needed for DialFire format
    return /^\d{4,}$/.test(contactOwnerId);
  }

  // Get team names for dropdown/selection
  getTeamNames(): string[] {
    return Array.from(new Set(
      Array.from(this.mappings.values())
        .filter(mapping => mapping.isActive)
        .map(mapping => mapping.teamName)
    )).sort();
  }

  // Get contact owner IDs for a team
  getContactOwnerIds(teamName: string): string[] {
    return Array.from(this.mappings.values())
      .filter(mapping => mapping.isActive && mapping.teamName === teamName)
      .map(mapping => mapping.contactOwnerId);
  }

  // Bulk import mappings
  importMappings(mappings: CreateTeamMappingRequest[]): {
    imported: number;
    skipped: number;
    errors: string[];
  } {
    const results = {
      imported: 0,
      skipped: 0,
      errors: [] as string[],
    };

    mappings.forEach((mapping, index) => {
      try {
        if (!this.isValidContactOwnerId(mapping.contactOwnerId)) {
          results.errors.push(`Row ${index + 1}: Invalid contact owner ID format`);
          results.skipped++;
          return;
        }

        if (!mapping.teamName.trim()) {
          results.errors.push(`Row ${index + 1}: Team name is required`);
          results.skipped++;
          return;
        }

        this.setTeamMapping(mapping);
        results.imported++;
      } catch (error) {
        results.errors.push(`Row ${index + 1}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        results.skipped++;
      }
    });

    return results;
  }

  // Export mappings for backup/sharing
  exportMappings(): TeamMapping[] {
    return this.getAllMappingsIncludingInactive();
  }

  // Reset to default mappings
  resetToDefaults(): void {
    this.mappings.clear();
    this.ensureDefaultMappings();
  }

  // Search mappings
  searchMappings(query: string): TeamMapping[] {
    const searchTerm = query.toLowerCase();
    return Array.from(this.mappings.values()).filter(mapping =>
      mapping.teamName.toLowerCase().includes(searchTerm) ||
      mapping.contactOwnerId.includes(searchTerm) ||
      (mapping.description && mapping.description.toLowerCase().includes(searchTerm))
    );
  }
}

// Export singleton instance
export const teamMapping = new TeamMappingService();

// React hook for team mappings
export const useTeamMapping = () => {
  const getTeamName = (contactOwnerId: string) => {
    return teamMapping.getTeamName(contactOwnerId);
  };

  const getAllMappings = () => {
    return teamMapping.getAllMappings();
  };

  const setTeamMapping = (request: CreateTeamMappingRequest) => {
    return teamMapping.setTeamMapping(request);
  };

  const updateTeamMapping = (
    contactOwnerId: string, 
    updates: Partial<Pick<TeamMapping, 'teamName' | 'description' | 'isActive'>>
  ) => {
    return teamMapping.updateTeamMapping(contactOwnerId, updates);
  };

  const deleteTeamMapping = (contactOwnerId: string) => {
    return teamMapping.deleteTeamMapping(contactOwnerId);
  };

  const getTeamStats = () => {
    return teamMapping.getTeamStats();
  };

  return {
    getTeamName,
    getAllMappings,
    setTeamMapping,
    updateTeamMapping,
    deleteTeamMapping,
    getTeamStats,
  };
};

export default TeamMappingService;
