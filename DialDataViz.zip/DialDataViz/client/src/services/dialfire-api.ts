// DialFire API Integration Service
// This service handles all interactions with the DialFire API

export interface DialFireConfig {
  apiToken: string;
  baseUrl: string;
}

export interface DialFireCall {
  id: string;
  callerId: string;
  campaignId: string;
  duration: number;
  wasSuccessful: boolean;
  callDate: string;
  contactOwnerId: string;
}

export interface DialFireCaller {
  id: string;
  name: string;
  contactOwnerId: string;
  isActive: boolean;
}

export interface DialFireCampaign {
  id: string;
  name: string;
  isActive: boolean;
}

export interface SyncCallsRequest {
  campaignId: string;
  startDate: string;
  endDate: string;
}

export interface SyncCallsResponse {
  calls: DialFireCall[];
  totalCount: number;
  syncedCount: number;
}

class DialFireApiService {
  private config: DialFireConfig;

  constructor() {
    // Get API configuration from environment variables
    this.config = {
      apiToken: import.meta.env.VITE_DIALFIRE_API_TOKEN || process.env.DIALFIRE_API_TOKEN || "",
      baseUrl: import.meta.env.VITE_DIALFIRE_BASE_URL || process.env.DIALFIRE_BASE_URL || "https://api.dialfire.com/v1",
    };

    if (!this.config.apiToken) {
      console.warn("DialFire API token not configured. API calls will fail.");
    }
  }

  private async makeRequest<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
    const url = `${this.config.baseUrl}${endpoint}`;
    
    const defaultHeaders = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${this.config.apiToken}`,
    };

    const response = await fetch(url, {
      ...options,
      headers: {
        ...defaultHeaders,
        ...options.headers,
      },
    });

    if (!response.ok) {
      const errorData = await response.text().catch(() => 'Unknown error');
      throw new Error(`DialFire API Error (${response.status}): ${errorData}`);
    }

    return response.json();
  }

  // Get all campaigns
  async getCampaigns(): Promise<DialFireCampaign[]> {
    try {
      const response = await this.makeRequest<{ campaigns: DialFireCampaign[] }>('/campaigns');
      return response.campaigns || [];
    } catch (error) {
      console.error('Failed to fetch campaigns from DialFire:', error);
      throw error;
    }
  }

  // Get callers for a campaign
  async getCallers(campaignId: string): Promise<DialFireCaller[]> {
    try {
      const response = await this.makeRequest<{ callers: DialFireCaller[] }>(`/campaigns/${campaignId}/callers`);
      return response.callers || [];
    } catch (error) {
      console.error('Failed to fetch callers from DialFire:', error);
      throw error;
    }
  }

  // Get calls for a date range
  async getCalls(params: {
    campaignId: string;
    startDate: string;
    endDate: string;
    callerId?: string;
    contactOwnerId?: string;
    limit?: number;
    offset?: number;
  }): Promise<SyncCallsResponse> {
    try {
      const queryParams = new URLSearchParams();
      queryParams.append('start_date', params.startDate);
      queryParams.append('end_date', params.endDate);
      
      if (params.callerId) queryParams.append('caller_id', params.callerId);
      if (params.contactOwnerId) queryParams.append('contact_owner_id', params.contactOwnerId);
      if (params.limit) queryParams.append('limit', params.limit.toString());
      if (params.offset) queryParams.append('offset', params.offset.toString());

      const response = await this.makeRequest<SyncCallsResponse>(
        `/campaigns/${params.campaignId}/calls?${queryParams.toString()}`
      );
      
      return {
        calls: response.calls || [],
        totalCount: response.totalCount || 0,
        syncedCount: response.syncedCount || response.calls?.length || 0,
      };
    } catch (error) {
      console.error('Failed to fetch calls from DialFire:', error);
      throw error;
    }
  }

  // Get call statistics for a caller
  async getCallerStats(params: {
    campaignId: string;
    callerId: string;
    startDate: string;
    endDate: string;
  }): Promise<{
    totalCalls: number;
    successfulCalls: number;
    avgDuration: number;
    successRate: number;
  }> {
    try {
      const response = await this.makeRequest<any>(
        `/campaigns/${params.campaignId}/callers/${params.callerId}/stats?start_date=${params.startDate}&end_date=${params.endDate}`
      );
      
      return {
        totalCalls: response.total_calls || 0,
        successfulCalls: response.successful_calls || 0,
        avgDuration: response.avg_duration || 0,
        successRate: response.success_rate || 0,
      };
    } catch (error) {
      console.error('Failed to fetch caller stats from DialFire:', error);
      throw error;
    }
  }

  // Test API connection
  async testConnection(): Promise<boolean> {
    try {
      await this.makeRequest<any>('/health');
      return true;
    } catch (error) {
      console.error('DialFire API connection test failed:', error);
      return false;
    }
  }

  // Bulk sync calls to local storage
  async syncCalls(params: SyncCallsRequest): Promise<{
    success: boolean;
    syncedCount: number;
    errors: string[];
  }> {
    try {
      const { calls, syncedCount } = await this.getCalls({
        campaignId: params.campaignId,
        startDate: params.startDate,
        endDate: params.endDate,
        limit: 1000, // Adjust based on API limits
      });

      // Send calls to our backend for storage
      const response = await fetch('/api/dialfire/sync-calls', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          campaignId: params.campaignId,
          calls: calls,
        }),
      });

      if (!response.ok) {
        throw new Error(`Sync failed: ${response.statusText}`);
      }

      return {
        success: true,
        syncedCount: syncedCount,
        errors: [],
      };
    } catch (error) {
      console.error('Call sync failed:', error);
      return {
        success: false,
        syncedCount: 0,
        errors: [error instanceof Error ? error.message : 'Unknown sync error'],
      };
    }
  }

  // Get contact owners (for team mapping)
  async getContactOwners(campaignId: string): Promise<Array<{ id: string; name: string }>> {
    try {
      const response = await this.makeRequest<{ contact_owners: Array<{ id: string; name: string }> }>(
        `/campaigns/${campaignId}/contact-owners`
      );
      return response.contact_owners || [];
    } catch (error) {
      console.error('Failed to fetch contact owners from DialFire:', error);
      throw error;
    }
  }

  // Update configuration
  updateConfig(newConfig: Partial<DialFireConfig>) {
    this.config = { ...this.config, ...newConfig };
  }

  // Get current configuration (without exposing sensitive data)
  getConfig(): { baseUrl: string; hasToken: boolean } {
    return {
      baseUrl: this.config.baseUrl,
      hasToken: Boolean(this.config.apiToken),
    };
  }
}

// Export singleton instance
export const dialFireApi = new DialFireApiService();

// Export utility functions for React components
export const useDialFireSync = () => {
  const syncCalls = async (params: SyncCallsRequest) => {
    return dialFireApi.syncCalls(params);
  };

  const testConnection = async () => {
    return dialFireApi.testConnection();
  };

  return {
    syncCalls,
    testConnection,
  };
};

// Export types and service
export default DialFireApiService;
