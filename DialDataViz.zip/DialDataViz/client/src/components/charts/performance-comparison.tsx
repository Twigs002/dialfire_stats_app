import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";
import type { CallerStats, TeamStats } from "@shared/schema";

Chart.register(...registerables);

interface PerformanceComparisonProps {
  comparisonType: 'callers' | 'teams';
  callerStats: CallerStats[];
  teamStats: TeamStats[];
}

export default function PerformanceComparisonCharts({ 
  comparisonType, 
  callerStats, 
  teamStats 
}: PerformanceComparisonProps) {
  const volumeChartRef = useRef<HTMLCanvasElement>(null);
  const successChartRef = useRef<HTMLCanvasElement>(null);
  const durationChartRef = useRef<HTMLCanvasElement>(null);
  const trendChartRef = useRef<HTMLCanvasElement>(null);

  const volumeChartInstanceRef = useRef<Chart | null>(null);
  const successChartInstanceRef = useRef<Chart | null>(null);
  const durationChartInstanceRef = useRef<Chart | null>(null);
  const trendChartInstanceRef = useRef<Chart | null>(null);

  const colors = {
    primary: 'hsl(221.2, 83.2%, 53.3%)',
    accent: 'hsl(142.1, 76.2%, 36.3%)',
    chart2: 'hsl(38.7, 92%, 50%)',
    chart3: 'hsl(280.4, 89%, 62.7%)',
    chart4: 'hsl(0, 84.2%, 60.2%)',
    muted: 'hsl(215.4, 16.3%, 46.9%)'
  };

  const chartColors = [colors.primary, colors.accent, colors.chart2, colors.chart3, colors.chart4];

  useEffect(() => {
    const createChart = (
      canvasRef: React.RefObject<HTMLCanvasElement>,
      chartInstanceRef: React.MutableRefObject<Chart | null>,
      config: any
    ) => {
      if (!canvasRef.current) return;

      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }

      const ctx = canvasRef.current.getContext('2d');
      if (!ctx) return;

      chartInstanceRef.current = new Chart(ctx, config);
    };

    const commonOptions = {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          backgroundColor: 'hsl(0, 0%, 100%)',
          titleColor: 'hsl(222.2, 84%, 4.9%)',
          bodyColor: 'hsl(215.4, 16.3%, 46.9%)',
          borderColor: 'hsl(214.3, 31.8%, 91.4%)',
          borderWidth: 1,
          cornerRadius: 8,
        }
      },
      scales: {
        x: {
          grid: {
            color: 'hsl(214.3, 31.8%, 91.4%)',
          },
          ticks: {
            color: 'hsl(215.4, 16.3%, 46.9%)',
            maxRotation: 45,
          }
        },
        y: {
          beginAtZero: true,
          grid: {
            color: 'hsl(214.3, 31.8%, 91.4%)',
          },
          ticks: {
            color: 'hsl(215.4, 16.3%, 46.9%)',
          }
        }
      }
    };

    if (comparisonType === 'callers' && callerStats.length > 0) {
      // Take top 5 callers for better visualization
      const topCallers = callerStats.slice(0, 5);
      const callerNames = topCallers.map(stat => {
        const nameParts = stat.caller.name.split(' ');
        return nameParts.length > 1 ? `${nameParts[0]} ${nameParts[1][0]}.` : nameParts[0];
      });

      // Volume Chart
      createChart(volumeChartRef, volumeChartInstanceRef, {
        type: 'bar',
        data: {
          labels: callerNames,
          datasets: [{
            label: 'Total Calls',
            data: topCallers.map(stat => stat.totalCalls),
            backgroundColor: colors.primary,
            borderColor: colors.primary,
            borderWidth: 1,
            borderRadius: 4,
          }]
        },
        options: commonOptions
      });

      // Success Chart
      createChart(successChartRef, successChartInstanceRef, {
        type: 'bar',
        data: {
          labels: callerNames,
          datasets: [{
            label: 'Success Rate (%)',
            data: topCallers.map(stat => stat.successRate),
            backgroundColor: colors.accent,
            borderColor: colors.accent,
            borderWidth: 1,
            borderRadius: 4,
          }]
        },
        options: {
          ...commonOptions,
          scales: {
            ...commonOptions.scales,
            y: {
              ...commonOptions.scales.y,
              max: 100
            }
          }
        }
      });

      // Duration Chart
      createChart(durationChartRef, durationChartInstanceRef, {
        type: 'bar',
        data: {
          labels: callerNames,
          datasets: [{
            label: 'Avg Duration (min)',
            data: topCallers.map(stat => Math.round(stat.avgDuration / 60 * 100) / 100),
            backgroundColor: colors.chart2,
            borderColor: colors.chart2,
            borderWidth: 1,
            borderRadius: 4,
          }]
        },
        options: commonOptions
      });

      // Trend Chart - Mock weekly data for demonstration
      const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
      const datasets = topCallers.slice(0, 3).map((stat, index) => ({
        label: callerNames[index],
        data: weekDays.map(() => Math.floor(stat.totalCalls / 7) + Math.floor(Math.random() * 20) - 10),
        borderColor: chartColors[index],
        backgroundColor: chartColors[index] + '20',
        tension: 0.4,
        pointRadius: 4,
        pointHoverRadius: 6,
      }));

      createChart(trendChartRef, trendChartInstanceRef, {
        type: 'line',
        data: {
          labels: weekDays,
          datasets
        },
        options: {
          ...commonOptions,
          plugins: {
            ...commonOptions.plugins,
            legend: {
              display: true,
              position: 'bottom',
              labels: {
                padding: 20,
                usePointStyle: true,
                color: 'hsl(222.2, 84%, 4.9%)',
                font: {
                  family: 'Inter',
                  size: 12,
                }
              }
            }
          }
        }
      });

    } else if (comparisonType === 'teams' && teamStats.length > 0) {
      const teamNames = teamStats.map(stat => stat.team.name);

      // Team Volume Chart
      createChart(volumeChartRef, volumeChartInstanceRef, {
        type: 'bar',
        data: {
          labels: teamNames,
          datasets: [{
            label: 'Total Calls',
            data: teamStats.map(stat => stat.totalCalls),
            backgroundColor: teamNames.map((_, index) => chartColors[index % chartColors.length]),
            borderWidth: 1,
            borderRadius: 4,
          }]
        },
        options: commonOptions
      });

      // Team Success Chart (Radar)
      createChart(successChartRef, successChartInstanceRef, {
        type: 'radar',
        data: {
          labels: ['Call Volume', 'Success Rate', 'Avg Calls/Member', 'Team Size', 'Efficiency'],
          datasets: teamStats.map((stat, index) => ({
            label: stat.team.name,
            data: [
              Math.min(stat.totalCalls / 100, 100), // Normalize to 100
              stat.successRate,
              Math.min(stat.avgCallsPerMember / 10, 100), // Normalize
              Math.min(stat.memberCount * 10, 100), // Normalize
              Math.min(stat.successRate + stat.trend, 100) // Efficiency score
            ],
            borderColor: chartColors[index % chartColors.length],
            backgroundColor: chartColors[index % chartColors.length] + '20',
            pointBackgroundColor: chartColors[index % chartColors.length],
            pointBorderColor: '#fff',
            pointHoverBackgroundColor: '#fff',
            pointHoverBorderColor: chartColors[index % chartColors.length],
          }))
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              display: true,
              position: 'bottom',
              labels: {
                padding: 20,
                color: 'hsl(222.2, 84%, 4.9%)',
                font: {
                  family: 'Inter',
                  size: 12,
                }
              }
            }
          },
          scales: {
            r: {
              beginAtZero: true,
              max: 100,
              ticks: {
                color: 'hsl(215.4, 16.3%, 46.9%)',
                backdropColor: 'transparent'
              },
              grid: {
                color: 'hsl(214.3, 31.8%, 91.4%)'
              },
              angleLines: {
                color: 'hsl(214.3, 31.8%, 91.4%)'
              }
            }
          }
        }
      });

      // Team Timeline Chart - Mock monthly data
      const months = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
      const teamDatasets = teamStats.map((stat, index) => ({
        label: stat.team.name,
        data: months.map(() => Math.floor(stat.totalCalls / 4) + Math.floor(Math.random() * 100) - 50),
        borderColor: chartColors[index % chartColors.length],
        backgroundColor: chartColors[index % chartColors.length] + '20',
        tension: 0.4,
        fill: true,
        pointRadius: 4,
        pointHoverRadius: 6,
      }));

      createChart(trendChartRef, trendChartInstanceRef, {
        type: 'line',
        data: {
          labels: months,
          datasets: teamDatasets
        },
        options: {
          ...commonOptions,
          plugins: {
            ...commonOptions.plugins,
            legend: {
              display: true,
              position: 'bottom',
              labels: {
                padding: 20,
                usePointStyle: true,
                color: 'hsl(222.2, 84%, 4.9%)',
                font: {
                  family: 'Inter',
                  size: 12,
                }
              }
            }
          }
        }
      });

      // Duration chart for teams - show average call duration
      createChart(durationChartRef, durationChartInstanceRef, {
        type: 'bar',
        data: {
          labels: teamNames,
          datasets: [{
            label: 'Avg Calls per Member',
            data: teamStats.map(stat => stat.avgCallsPerMember),
            backgroundColor: colors.chart2,
            borderColor: colors.chart2,
            borderWidth: 1,
            borderRadius: 4,
          }]
        },
        options: commonOptions
      });
    }

    return () => {
      [volumeChartInstanceRef, successChartInstanceRef, durationChartInstanceRef, trendChartInstanceRef]
        .forEach(ref => {
          if (ref.current) {
            ref.current.destroy();
          }
        });
    };
  }, [comparisonType, callerStats, teamStats]);

  const renderEmptyState = (title: string) => (
    <div className="flex items-center justify-center h-full text-muted-foreground">
      <div className="text-center">
        <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
          </svg>
        </div>
        <p className="text-sm font-medium">No data available</p>
        <p className="text-xs mt-1">{title} will appear once data is loaded</p>
      </div>
    </div>
  );

  const hasData = comparisonType === 'callers' ? callerStats.length > 0 : teamStats.length > 0;

  if (comparisonType === 'callers') {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Call Volume Comparison</h3>
          <div className="chart-container">
            {hasData ? (
              <canvas ref={volumeChartRef} data-testid="caller-volume-chart" />
            ) : (
              renderEmptyState("Call volume data")
            )}
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Success Rate Comparison</h3>
          <div className="chart-container">
            {hasData ? (
              <canvas ref={successChartRef} data-testid="caller-success-chart" />
            ) : (
              renderEmptyState("Success rate data")
            )}
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Average Call Duration</h3>
          <div className="chart-container">
            {hasData ? (
              <canvas ref={durationChartRef} data-testid="caller-duration-chart" />
            ) : (
              renderEmptyState("Duration data")
            )}
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Weekly Performance Trend</h3>
          <div className="chart-container">
            {hasData ? (
              <canvas ref={trendChartRef} data-testid="caller-trend-chart" />
            ) : (
              renderEmptyState("Trend data")
            )}
          </div>
        </div>
      </div>
    );
  }

  // Team comparison layout
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Team Call Volume</h3>
          <div className="chart-container">
            {hasData ? (
              <canvas ref={volumeChartRef} data-testid="team-volume-chart" />
            ) : (
              renderEmptyState("Team volume data")
            )}
          </div>
        </div>

        <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Team Success Rates</h3>
          <div className="chart-container">
            {hasData ? (
              <canvas ref={successChartRef} data-testid="team-success-chart" />
            ) : (
              renderEmptyState("Success rate data")
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        <div className="bg-card rounded-lg p-6 border border-border shadow-sm">
          <h3 className="text-lg font-semibold text-foreground mb-4">Team Performance Over Time</h3>
          <div className="chart-container" style={{ height: '350px' }}>
            {hasData ? (
              <canvas ref={trendChartRef} data-testid="team-timeline-chart" />
            ) : (
              renderEmptyState("Timeline data")
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
