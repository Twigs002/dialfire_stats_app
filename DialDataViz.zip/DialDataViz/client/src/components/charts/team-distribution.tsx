import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

interface TeamDistributionProps {
  data: Array<{ team: string; calls: number }>;
}

export default function TeamDistributionChart({ data }: TeamDistributionProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!chartRef.current || data.length === 0) return;

    // Destroy existing chart
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    const colors = [
      'hsl(221.2, 83.2%, 53.3%)', // primary
      'hsl(142.1, 76.2%, 36.3%)', // accent
      'hsl(280.4, 89%, 62.7%)',   // chart-4
      'hsl(38.7, 92%, 50%)',      // chart-3
      'hsl(0, 84.2%, 60.2%)',     // chart-5
    ];

    chartInstanceRef.current = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: data.map(item => item.team),
        datasets: [{
          data: data.map(item => item.calls),
          backgroundColor: colors.slice(0, data.length),
          borderColor: colors.slice(0, data.length),
          borderWidth: 2,
          hoverBorderWidth: 3,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '60%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              padding: 20,
              usePointStyle: true,
              pointStyle: 'circle',
              color: 'hsl(222.2, 84%, 4.9%)',
              font: {
                family: 'Inter',
                size: 12,
                weight: 500,
              }
            }
          },
          tooltip: {
            backgroundColor: 'hsl(0, 0%, 100%)',
            titleColor: 'hsl(222.2, 84%, 4.9%)',
            bodyColor: 'hsl(215.4, 16.3%, 46.9%)',
            borderColor: 'hsl(214.3, 31.8%, 91.4%)',
            borderWidth: 1,
            cornerRadius: 8,
            callbacks: {
              label: function(context) {
                const total = context.dataset.data.reduce((sum: number, value: any) => sum + value, 0);
                const percentage = ((context.parsed / total) * 100).toFixed(1);
                return `${context.label}: ${context.parsed.toLocaleString()} calls (${percentage}%)`;
              }
            }
          }
        },
        elements: {
          arc: {
            borderRadius: 4,
          }
        },
        animation: {
          animateRotate: true,
          animateScale: true,
          duration: 1000,
        }
      }
    });

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
    };
  }, [data]);

  if (data.length === 0) {
    return (
      <div className="flex items-center justify-center h-full text-muted-foreground" data-testid="team-distribution-empty">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <p className="text-sm font-medium">No team data available</p>
          <p className="text-xs mt-1">Team distribution will appear once calls are logged</p>
        </div>
      </div>
    );
  }

  return <canvas ref={chartRef} data-testid="team-distribution-chart" />;
}
