import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

interface CallsOverTimeProps {
  data: Array<{ date: string; calls: number }>;
}

export default function CallsOverTimeChart({ data }: CallsOverTimeProps) {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  useEffect(() => {
    if (!chartRef.current || data.length === 0) return;

    // Destroy existing chart
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    // Format dates for display
    const labels = data.map(item => {
      const date = new Date(item.date);
      return date.toLocaleDateString('en-US', { weekday: 'short' });
    });

    chartInstanceRef.current = new Chart(ctx, {
      type: 'line',
      data: {
        labels,
        datasets: [{
          label: 'Calls',
          data: data.map(item => item.calls),
          borderColor: 'hsl(221.2, 83.2%, 53.3%)',
          backgroundColor: 'hsl(221.2, 83.2%, 53.3%, 0.1)',
          tension: 0.4,
          fill: true,
          pointRadius: 4,
          pointHoverRadius: 6,
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { 
            display: false 
          },
          tooltip: {
            backgroundColor: 'hsl(0, 0%, 100%)',
            titleColor: 'hsl(222.2, 84%, 4.9%)',
            bodyColor: 'hsl(215.4, 16.3%, 46.9%)',
            borderColor: 'hsl(214.3, 31.8%, 91.4%)',
            borderWidth: 1,
            cornerRadius: 8,
          }
        },
        scales: {
          x: {
            grid: {
              color: 'hsl(214.3, 31.8%, 91.4%)',
            },
            ticks: {
              color: 'hsl(215.4, 16.3%, 46.9%)',
            }
          },
          y: {
            beginAtZero: true,
            grid: {
              color: 'hsl(214.3, 31.8%, 91.4%)',
            },
            ticks: {
              color: 'hsl(215.4, 16.3%, 46.9%)',
            }
          }
        },
        elements: {
          point: {
            backgroundColor: 'hsl(221.2, 83.2%, 53.3%)',
            borderColor: 'hsl(0, 0%, 100%)',
            borderWidth: 2,
          }
        }
      }
    });

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
    };
  }, [data]);

  return <canvas ref={chartRef} data-testid="calls-over-time-chart" />;
}
