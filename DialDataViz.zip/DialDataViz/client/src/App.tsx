import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Sidebar from "@/components/layout/sidebar";
import Overview from "@/pages/overview";
import CallerStats from "@/pages/caller-stats";
import TeamPerformance from "@/pages/team-performance";
import PerformanceComparison from "@/pages/performance-comparison";
import ThresholdAlerts from "@/pages/threshold-alerts";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="flex min-h-screen bg-muted">
      <Sidebar />
      <main className="md:ml-64 flex-1">
        <Switch>
          <Route path="/" component={Overview} />
          <Route path="/caller-stats" component={CallerStats} />
          <Route path="/team-performance" component={TeamPerformance} />
          <Route path="/performance-comparison" component={PerformanceComparison} />
          <Route path="/threshold-alerts" component={ThresholdAlerts} />
          <Route component={NotFound} />
        </Switch>
      </main>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
