import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, decimal, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const campaigns = pgTable("campaigns", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  dialfireId: text("dialfire_id").notNull().unique(),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`),
});

export const teams = pgTable("teams", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  contactOwnerId: text("contact_owner_id").notNull().unique(),
  campaignId: varchar("campaign_id").references(() => campaigns.id),
});

export const callers = pgTable("callers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  dialfireId: text("dialfire_id").notNull().unique(),
  teamId: varchar("team_id").references(() => teams.id),
  isActive: boolean("is_active").default(true),
});

export const calls = pgTable("calls", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  callerId: varchar("caller_id").references(() => callers.id),
  campaignId: varchar("campaign_id").references(() => campaigns.id),
  duration: integer("duration"), // in seconds
  wasSuccessful: boolean("was_successful").default(false),
  callDate: timestamp("call_date").notNull(),
  dialfireCallId: text("dialfire_call_id").unique(),
});

export const thresholds = pgTable("thresholds", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  campaignId: varchar("campaign_id").references(() => campaigns.id),
  minDailyCalls: integer("min_daily_calls").default(50),
  minSuccessRate: decimal("min_success_rate", { precision: 5, scale: 2 }).default("70.00"),
  minAvgDuration: integer("min_avg_duration").default(240), // in seconds
  weeklyTarget: integer("weekly_target").default(350),
});

export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  callerId: varchar("caller_id").references(() => callers.id),
  alertType: text("alert_type").notNull(), // "daily_calls", "success_rate", "avg_duration", "weekly_target"
  currentValue: decimal("current_value", { precision: 10, scale: 2 }),
  thresholdValue: decimal("threshold_value", { precision: 10, scale: 2 }),
  severity: text("severity").notNull(), // "critical", "warning"
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").default(sql`now()`),
});

// Insert schemas
export const insertCampaignSchema = createInsertSchema(campaigns).omit({
  id: true,
  createdAt: true,
});

export const insertTeamSchema = createInsertSchema(teams).omit({
  id: true,
});

export const insertCallerSchema = createInsertSchema(callers).omit({
  id: true,
});

export const insertCallSchema = createInsertSchema(calls).omit({
  id: true,
});

export const insertThresholdSchema = createInsertSchema(thresholds).omit({
  id: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

// Types
export type Campaign = typeof campaigns.$inferSelect;
export type Team = typeof teams.$inferSelect;
export type Caller = typeof callers.$inferSelect;
export type Call = typeof calls.$inferSelect;
export type Threshold = typeof thresholds.$inferSelect;
export type Alert = typeof alerts.$inferSelect;

export type InsertCampaign = z.infer<typeof insertCampaignSchema>;
export type InsertTeam = z.infer<typeof insertTeamSchema>;
export type InsertCaller = z.infer<typeof insertCallerSchema>;
export type InsertCall = z.infer<typeof insertCallSchema>;
export type InsertThreshold = z.infer<typeof insertThresholdSchema>;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

// Additional types for API responses
export type CallerStats = {
  caller: Caller;
  team: Team;
  totalCalls: number;
  successfulCalls: number;
  successRate: number;
  avgDuration: number;
  dailyCalls: number;
  weeklyCalls: number;
  trend: number; // percentage change
};

export type TeamStats = {
  team: Team;
  totalCalls: number;
  memberCount: number;
  successRate: number;
  avgCallsPerMember: number;
  trend: number;
};

export type DashboardStats = {
  totalCalls: number;
  activeCallers: number;
  avgDuration: string;
  successRate: number;
  callsOverTime: Array<{ date: string; calls: number }>;
  teamDistribution: Array<{ team: string; calls: number }>;
};
